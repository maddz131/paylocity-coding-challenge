export const variables = {
    API_URL: "http://localhost:5080/api/"
}