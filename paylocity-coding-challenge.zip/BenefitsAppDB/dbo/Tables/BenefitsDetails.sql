﻿CREATE TABLE [dbo].[BenefitsDetails]
(
	[EmployeeBenefitsYearlyCost] INT NOT NULL,
	[DependentBenefitsYearlyCost] INT NOT NULL,
	[Paycheck] INT NOT NULL,
	[PayPeriodsPerYear] INT NOT NULL,
	[PercentDiscount] INT NOT NULL
)
