﻿namespace BenefitsApi.Dto
{
    public class EmployeeDto
    {
        //what will the user enter into the form
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
